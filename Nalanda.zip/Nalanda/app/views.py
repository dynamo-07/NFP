from django.shortcuts import render,redirect,get_object_or_404
from .forms import *
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from datetime import datetime
from django.contrib.auth.models import User
import time
# Create your views here.
@login_required(login_url="login")
def home(request):
    try:
        if request.user.groups.filter(name="Admin"):
            return render(request,'home.html')
        current_date_formatted = datetime.now().strftime("%Y-%m-%d")
        bookuser=foodbook.objects.filter(user =request.user)
        dic_data={
                'data':bookuser.filter(date=current_date_formatted),
                'time':time.strftime("%H:%M:%S") if time.strftime("%H:%M:%S") > "12:20:00" else "",
                'time1':time.strftime("%H:%M:%S") if time.strftime("%H:%M:%S") >"14:00:00" and time.strftime("%H:%M:%S") <"17:00:00" else ""
            }
        return render(request,'home.html',{'data1':dic_data})
    except:
        messages.error(request,"Error occured 404")
        return redirect('login')
    

def Loginuser(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request,user)
            welmes = f"Welcome {request.user.username}"
            messages.info(request, welmes)
            return redirect('home')
        else:
            messages.error(request,"Invalid username or password")
            return render(request, 'login.html')
    return render(request, 'login.html')


@login_required(login_url="login")
def book1(request):
    try:
        if request.method =="POST":
            form=contactform(request.POST)
            if form.is_valid():
                c=form.save(commit=False)
                c.user = request.user
                messages.success(request,"Your request has ben sent successfully")
                c.save()
                return redirect('home')
        return render(request,'help.html')
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')


@login_required(login_url="login")
def feedbackuser(request):
    try:
        if time.strftime("%H:%M:%S") < "14:00:00":
            messages.info(request,"Your are too early")
            return redirect('home')
        if time.strftime("%H:%M:%S") > "18:00:00":
            messages.info(request,"Your Time has been over")
            return redirect('home')
        if request.method =="POST":
            form = feed(request.POST)
            if form.is_valid():
                c=form.save(commit=False)
                c.user = request.user
                c.save()
                messages.success(request,"Your request has ben sent successfully")
                return redirect("home")
        return render(request,"feedback.html")
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')

@login_required(login_url="login")
def foodbookuser(request):
    try:
        if request.user.groups.filter(name="Admin"):
            if request.method =="POST":
                form=food(request.POST)
                if form.is_valid():
                    c=form.save(commit=False)
                    user_instance = User.objects.get(username=request.POST.get('name'))
                    c.user = user_instance
                    c.save()
                    messages.success(request,"Your meal has ben booked successfully")
                    return redirect("home")
            user=User.objects.all
            current_date_formatted = datetime.now().strftime("%Y-%m-%d")
            dic_data={
                'user':user,
                'date':current_date_formatted
            }
            return render(request,"foodbook.html",{"date":dic_data})
        if time.strftime("%H:%M:%S") > "12:20:00":
            messages.info(request,"Your Booking Time is Over")
            return redirect('home')
        if request.method =="POST":
            form=food(request.POST)
            if form.is_valid():
                c=form.save(commit=False)
                c.user = request.user
                if time.strftime("%H:%M:%S") > "12:20:00":
                    messages.info(request,"Your Booking Time is Over")
                    return redirect('home')
                c.save()
                messages.success(request,"Your meal has ben booked successfully")
                return redirect("home")    
        current_date_formatted = datetime.now().strftime("%Y-%m-%d")
        return render(request,"foodbook.html",{"date":current_date_formatted})
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')


@login_required(login_url="login")
def booklist(request):
    try:
        current_date_formatted = datetime.now().strftime("%Y-%m-%d")
        if request.user.groups.filter(name="Admin"):
            data=foodbook.objects.filter(date = current_date_formatted)
            lenth=len(data)
            if not data.exists():
                data=False
            dic_data={
                'date':data,
                'length':lenth,
            }
            return render(request,"booklist.html",{"dic_data": dic_data})
        data=foodbook.objects.filter(user = request.user)
        confirmdata=data.filter(date = current_date_formatted)
        if not confirmdata.exists():
                confirmdata=False
        dic_data={
                'data':confirmdata,
                'time':time.strftime("%H:%M:%S") if time.strftime("%H:%M:%S") > "12:20:00" else ""
            }
        return render(request,"booklist.html",{"dic_data": dic_data})
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')

    
@login_required(login_url="login")
def deleteuser(request,id):
    try:
        customer = get_object_or_404(foodbook, id=id)
        customer.delete()
        messages.success(request,"Your meal has ben canceled successfully")
        return redirect('booklist')
    except:
        messages.error(request,"Error occured while deleting data")
        return redirect('booklist')


@login_required(login_url="login")
def Logoutuser(request):
    try:
        logout(request)
        return redirect("login")
    except:
        messages.error(request,"Error occured 404")
        return redirect('login')

@login_required(login_url="login")
def feedbacklist(request):
    try:
        if request.user.groups.filter(name="Admin"):
            return render(request,"feedbacklist.html",{'dic_data':feedback.objects.all()})
        return render(request,"feedbacklist.html")
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')

@login_required(login_url="login")
def helplist(request):
    try:
        if request.user.groups.filter(name="Admin"):
            return render(request,"helplist.html",{'dic_data':contact.objects.all()})
        return render(request,"helplist.html")
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')

@login_required(login_url="login")
def helpview(request,id):
    try:
        return render(request,"helpview.html",{'data':get_object_or_404(contact,id=id)})
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')
    
@login_required(login_url="login")
def feedbackview(request,id):
    try:
        return render(request,"feedbackview.html",{'data':get_object_or_404(feedback,id=id)})
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')
    
@login_required(login_url="login")
def aboutus(request):
    try:
        return render(request,"aboutus.html")
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')
    
@login_required(login_url="login")
def userlist(request):
    return render(request,'userlist.html',{'dic_data':User.objects.all()})

@login_required(login_url="login")
def useradd(request):
    try:
        if request.method == 'POST':
            user_id = request.POST.get('userid')
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')

            if password != confirm_password:
                messages.error(request, "Passwords do not match!")
                return render(request, 'useradd.html')

            if User.objects.filter(id=user_id).exists():
                messages.error(request, "User ID already exists!")
                return render(request, 'useradd.html')

            if User.objects.filter(username=username).exists():
                messages.error(request, "Username already exists!")
                return render(request, 'useradd.html')

            try:
                user = User.objects.create_user(id=user_id, username=username, email=email, password=password)
                messages.success(request, f"User {user.username} created successfully!")
                return redirect('userlist')  # Redirecting to the user list view
            except IntegrityError as e:
                messages.error(request, f"Database error: {e}")
                return render(request, 'useradd.html')
            except Exception as e:
                messages.error(request, f"Error while creating user: {e}")
                return render(request, 'useradd.html')

        return render(request, 'useradd.html')
    
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')
    
def delete_user(request, id):
    try:
        user_name = request.user  
        user = User.objects.get(id=id)  
        
        if user_name == user:
            messages.error(request, "You cannot delete your own account.")
            return redirect('userlist')
        
        if user.is_superuser:
            messages.error(request, "You cannot delete a superuser.")
            return redirect('userlist')
        
        # Delete the user
        user.delete()
        messages.success(request, f"User {user.username} deleted successfully!")
        return redirect('userlist') 
    except:
        messages.error(request,"Error occured 404")
        return redirect('home')