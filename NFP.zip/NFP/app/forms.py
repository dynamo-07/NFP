from django import forms
from .models import *

class contact(forms.ModelForm):
    class Meta:
        model = contact
        fields = '__all__'