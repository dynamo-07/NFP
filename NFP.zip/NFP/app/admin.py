from .models import *

from django.contrib import admin
admin.site.register(contact)
# Register your models1 here.
