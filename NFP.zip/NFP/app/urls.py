from django.urls import path
from .views import *
urlpatterns = [
    path('login',login,name='login'),
    path('',home,name='home'),
    path('book1/',book1,name='help'),
    path('feedback/',feedback,name='feedback'),
    path('foodbook/',foodbook,name='foodbook'),
]
