from django.shortcuts import render,redirect
from .forms import *
# Create your views here.
def home(request):
    return render(request,'home.html')

def login(request):
    return render(request,'login.html')

def book1(request):
    if request.method =="post":
        form=contact(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    return render(request,'help.html')

def feedback(request):
    return render(request,"feedback.html")
def foodbook(request):
    return render(request,"foodbook.html")