from .models import *

from django.contrib import admin
admin.site.register(contact)
admin.site.register(feedback)
# Register your models1 here.
