from django.urls import path
from .views import *
urlpatterns = [
    path('login',login,name='login'),
    path('',index,name='index'),
    path('book1/',book1,name='book1'),
]
